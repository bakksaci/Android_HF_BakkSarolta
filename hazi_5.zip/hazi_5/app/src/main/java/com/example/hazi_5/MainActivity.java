package com.example.hazi_5;

 import android.os.Bundle;
         import android.view.ContextMenu;
         import android.view.Menu;
         import android.view.MenuItem;
         import android.view.View;
         import android.widget.AdapterView;
         import android.widget.ArrayAdapter;
         import android.widget.ListView;
         import androidx.annotation.NonNull;
         import androidx.annotation.Nullable;
         import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.list_items));
        listView.setAdapter(adapter);

        // Kontextusmenü regisztrálása a listához
        registerForContextMenu(listView);
    }

    // Kontextusmenü létrehozása
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.context_menu, menu);
    }

    // Kontextusmenü elemek kezelése
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        String selectedItem = adapter.getItem(info.position);

        switch (item.getItemId()) {
            case R.id.red:
                // Változtasd meg a lista elemének színét pirosra
                break;
            case R.id.green:
                // Változtasd meg a lista elemének színét zöldre
                break;
            case R.id.yellow:
                // Változtasd meg a lista elemének színét sárgára
                break;
        }
        return true;
    }


    // Opciós menü létrehozása
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    // Opciós menü elemek kezelése
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.sort:
                // Lista rendezése ábécé szerint
                break;
            case R.id.delete:
                // Teljes lista törlése
                break;
        }
        return true;
    }
}